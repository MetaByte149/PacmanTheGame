var WASD_dir = null; //wasd last pressed direction
var ULDR_dir = null; //arrow last pressed direction

var debugMode = false;
var GRIDSIZE = WALL = PLAYER = HALF_GRIDSIZE = COLS = ROWS = null;

var grid = [];
var walls = [];
var width = height = player1 = null;


  function pacmanSetup() {
    WALL = 'wall';
    PLAYER = 'player';
    GRIDSIZE = 26;
    HALF_GRIDSIZE = GRIDSIZE / 2;
    QUARTER_GRIDSIZE = GRIDSIZE / 4;
    COLS = 17;
    ROWS = 17;

    //creating Grid
    for(var j = 0; j < COLS; j++){
      for(var i = 0; i < ROWS; i++){
        grid.push(new Cell(i,j));
      }
    }

    



    wallBuilder();
    //creating pacman and ghosts
    player1 = new pacman();

  }//end of pacmanSetup()

  function setup() {

    angleMode(DEGREES);
    pacmanSetup();
    var width = COLS * GRIDSIZE;
    var height = ROWS * GRIDSIZE;
    createCanvas(width, height);
    

    
  }//end of setup


  function draw() {

    background(51);

    /* DEBUG MODE */
    if(debugMode){
      for(var i = 0; i < grid.length; i++){
        grid[i].show(); 
      }
    }

    for(var i = 0; i < walls.length; i++){ 
      walls[i].show();
    }

    player1.update();
    player1.show();
    
    


  }//end of draw


function keyPressed(){
      if       ((key == 'w' || key == 'W')) {   //up
        WASD_dir = 0;

      } else if((key == 'd' || key == 'D')) {   //right
        WASD_dir = 1;

      } else if((key == 's' || key == 'S')) {   //down
        WASD_dir = 2;

      } else if((key == 'a' || key == 'A')) {   //left
        WASD_dir = 3;

    
      } else if(keyCode == UP_ARROW) {    //up
        ULDR_dir = 0;

      } else if(keyCode == RIGHT_ARROW) {   //right
        ULDR_dir = 1;

      } else if(keyCode == DOWN_ARROW) {    //down
        ULDR_dir = 2;

      } else if(keyCode == LEFT_ARROW) {    //left
        ULDR_dir = 3;

      }
    
}





/*************************************************************/

function wallBuilder(){
    for (var i = 0; i < COLS; i++) { //top and bottom row
      createWall(i, 0);
      createWall(i, ROWS-1);
    }

    for (var i = 0; i < ROWS; i++) { //left and rightcolumn
      if(i != 8){
        createWall(0, i);
        createWall(COLS-1, i);
      }
    }
    


     //left up 
    createWall(2,2);
    createWall(2,3);
    createWall(4,1);
    createWall(3,3);

    //left up 
    createWall(5,3);
    createWall(6,2);
    createWall(6,3);
    


     //right up corner side
    
     //middle top

    createWall(8,1);
    createWall(8,2);
    createWall(8,3);
    createWall(9,5);
    createWall(7,5);
    //16 is highest column

    createWall(14,3);
    createWall(14,2);
    createWall(13,3);

    createWall(11,3);
    createWall(10,2);
    createWall(10,3);

    createWall(12,1);

    

    //middle block
    createWall(7,8);
    createWall(9,8);
    createWall(6,8);
    createWall(6,9);
    createWall(6,10);
    createWall(7,10);
    createWall(8,10);
    createWall(9,10);
    createWall(10,10);
    createWall(10,9);
    createWall(10,8);
    createWall(9,8);
    createWall(7,6);
    createWall(9,6);
    createWall(8,8,true);
    //

    createWall(5,5);
    createWall(4,5);
    createWall(3,5);
    createWall(1,5);

    createWall(11,5);
    createWall(12,5);
    createWall(13,5);
    createWall(15,5);

    //right teleporter
    createWall(15,7);
    createWall(14,7);
    createWall(13,7);
    createWall(12,7);
    createWall(15,9);
    createWall(14,9);
    createWall(13,9);
    createWall(12,9);

    //left teleporter
    createWall(1,7);
    createWall(2,7);
    createWall(3,7);
    createWall(4,7);
    createWall(1,9);
    createWall(2,9);
    createWall(3,9);
    createWall(4,9);

    //bottom left
    createWall(4,11);
    createWall(2,11);
    createWall(2,12);
    createWall(2,13);
    createWall(2,14);
    createWall(3,14);
    createWall(4,14);
    createWall(4,12);

    //bottom right
    createWall(14,11);
    createWall(14,14);
    createWall(14,12);
    createWall(14,13);
    createWall(13,14);
    createWall(12,14);
    createWall(12,11);
    createWall(12,12);

    //middle bottom
    createWall(6,14);
    createWall(7,14);
    createWall(9,14);
    createWall(10,14);

    //under middle
    createWall(11,12);
    createWall(10,12);
    createWall(8,12);
    createWall(6,12);
    createWall(5,12);
  }