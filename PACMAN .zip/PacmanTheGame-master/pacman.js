function pacman() {
	this.column = 8;
	this.row = 11;
	this.xOnGrid = GRIDSIZE / 2;
	this.yOnGrid = GRIDSIZE / 2;

	this.x = this.column * GRIDSIZE + this.xOnGrid;
	this.y = this.row * GRIDSIZE + this.yOnGrid;
	this.defaultSpeed = 3; this.speed = this.defaultSpeed;

	this.currentAnimation = 0;
	this.animationSpeed = 3;
	this.angle = 0;
	this.radius = GRIDSIZE/3; //was 10

	this.colorR = 255;
	this.colorG = 255;
	this.colorB = 0;
	this.color = color(this.colorR, this.colorG, this.colorB);

	this.temp = this.column + this.row * COLS;
	this.alive = true;
	
	this.checkTheGrid = function() {
		//updating location on the grid
		this.xOnGrid = this.x % this.column;
		this.yOnGrid = this.y % this.row;

		this.column = floor(this.x / GRIDSIZE);
		this.row = 	  floor(this.y / GRIDSIZE);

		



		
	}//end of this.checkTheGrid


	this.update = function() {

		

		switch(WASD_dir){
			case 0:
				this.angle = -90;
				this.y -= this.speed;

			break;

			case 1:
				this.angle = 0;
				this.x += this.speed;
			break;

			case 2:
				this.angle = 90;
				this.y += this.speed;
				
			break;

			case 3:
				this.angle = 180;
				this.x -= this.speed;

			break;
		}//end of WASD_dir switch


		//setting to other side when offscreen
		if(this.x < -this.radius){ 					//to the right of the screen
			this.x = width + this.radius;
		}else if(this.x > width + this.radius){		//to the left of the screen
			this.x = -this.radius;
		}











		
	}//end of this.update

	this.show = function(){
		push();

			translate(this.x, this.y);
			rotate(this.angle);

			//drawing
			fill(this.color); noStroke();
			arc(0, 0, this.radius*2, this.radius*2, 35 + this.currentAnimation, -35 - this.currentAnimation, PIE);

			//animation
			this.currentAnimation += this.animationSpeed;

			//switching between closing and opening the mouth
			if(this.currentAnimation > 20 || this.currentAnimation < -20){
				this.animationSpeed *= -1;
			}

		pop();

	}//end of this.show


	
}//end of pacman()