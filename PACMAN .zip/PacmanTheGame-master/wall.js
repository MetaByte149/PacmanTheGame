function wall(x, y){
	
	this.x = x;
	this.y = y;
	this.gate = false;

	this.width = GRIDSIZE;
	this.height = GRIDSIZE;

	this.colorR = random(75,125);
	this.colorG = random(75,125);
	this.colorB = random(150,255);
	this.color = color(this.colorR, this.colorG, this.colorB);

	this.show = function(){

		if(!this.gate){
			stroke(255, 100);
			strokeWeight(1);
			fill(this.color, 225);
			rect(this.x, this.y, this.width, this.height);
		}else{
			stroke(255, 100);
			strokeWeight(1);
			fill(255, 0, 0, 225);
			rect(this.x, this.y + 5, this.width, this.height - 20);
		}
	
	}
}

function createWall(i, j){

		
		this.column = i;
		this.row = j;


		this.x = i * GRIDSIZE;
		this.y = j * GRIDSIZE;


		walls.push(new wall(this.x, this.y, this.gate));
		grid[this.column + this.row * COLS].state = 'wall';

}