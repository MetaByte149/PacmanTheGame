  //making cells for grid
function Cell(i, j) {
    this.i = i;
    this.j = j;
    this.x = this.i * GRIDSIZE;
    this.y = this.j * GRIDSIZE;
    this.index = this.i + this.j * COLS;
    this.state = null;

    this.show = function(){
      switch(this.state){
        case WALL:
          fill(0);
        break;

        case PLAYER:
          fill(0, 255, 0);
        break;

        default:
          noFill();
        break; 
      }
      
      stroke(255);
      strokeWeight(1);
      rect(this.x, this.y, GRIDSIZE, GRIDSIZE);
      text(this.index, this.x, this.y + HALF_GRIDSIZE);

      
    }
}

